var searchData=
[
  ['_7ecjt_5fidiomes',['~Cjt_Idiomes',['../class_cjt___idiomes.html#ab36517bd1824e0f00cab6cf724b6ad6f',1,'Cjt_Idiomes']]],
  ['_7eidioma',['~Idioma',['../class_idioma.html#a80c90f8c9a7f824d7d7d171b9face201',1,'Idioma']]],
  ['_7etaula_5fde_5ffreq',['~Taula_de_freq',['../class_taula__de__freq.html#a046a70a0ea38d03da605998cf99d5335',1,'Taula_de_freq']]]
];
