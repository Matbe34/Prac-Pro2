var searchData=
[
  ['actualitza_5fidioma',['actualitza_idioma',['../class_cjt___idiomes.html#a7aad6974355b73c50c2d5c1edc0a5c14',1,'Cjt_Idiomes']]],
  ['actualitza_5ftaulacodis',['actualitza_taulacodis',['../class_idioma.html#ac089a0e4b79ca8f3df040e204a3de7dd',1,'Idioma']]],
  ['actualitza_5ftreecode',['actualitza_treecode',['../class_idioma.html#afcdc214d9490b61d54e35da85f2354a4',1,'Idioma']]],
  ['afegir_5fmodificar_5fidioma',['afegir_modificar_idioma',['../class_cjt___idiomes.html#a9e75f643c62886df635403bd3108c1df',1,'Cjt_Idiomes']]]
];
