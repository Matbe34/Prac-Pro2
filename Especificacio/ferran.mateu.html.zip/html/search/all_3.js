var searchData=
[
  ['escriure_5ftaulacodis',['escriure_taulacodis',['../class_cjt___idiomes.html#afdad5e96949152abf75a9598224be426',1,'Cjt_Idiomes::escriure_taulacodis()'],['../class_idioma.html#a4f1102ff409d13738ff09268e8e045da',1,'Idioma::escriure_taulacodis()']]],
  ['escriure_5ftaulafreq',['escriure_taulafreq',['../class_cjt___idiomes.html#a98862ab41b59ac71eca4408e2b6bf6f0',1,'Cjt_Idiomes::escriure_taulafreq()'],['../class_taula__de__freq.html#a2b05df9845a043e67775f923bdfd60a0',1,'Taula_de_freq::escriure_taulafreq()']]],
  ['escriure_5ftreecode',['escriure_treecode',['../class_cjt___idiomes.html#a49666adf7e2a9cefc96d4b7b3d925710',1,'Cjt_Idiomes::escriure_treecode()'],['../class_idioma.html#a2c3024b18da125926668a2df2b178992',1,'Idioma::escriure_treecode()']]]
];
