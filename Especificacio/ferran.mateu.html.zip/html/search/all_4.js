var searchData=
[
  ['gestió_20de_20la_20codificació_20i_20la_20decodificació_20en_20funció_20de_20diferents_20idiomes_2e',['Gestió de la codificació i la decodificació en funció de diferents idiomes.',['../index.html',1,'']]]
];
