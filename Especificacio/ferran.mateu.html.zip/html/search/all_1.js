var searchData=
[
  ['cjt_5fidiomes',['Cjt_Idiomes',['../class_cjt___idiomes.html',1,'Cjt_Idiomes'],['../class_cjt___idiomes.html#af77cbc534e3e83142a818314f5c24ae3',1,'Cjt_Idiomes::Cjt_Idiomes()']]],
  ['cjt_5fidiomes_2ehh',['Cjt_Idiomes.hh',['../_cjt___idiomes_8hh.html',1,'']]],
  ['codifica',['codifica',['../class_cjt___idiomes.html#a745de8e5d29e235cb1e2142d8acaaad9',1,'Cjt_Idiomes']]],
  ['consultar_5ftaula_5ffreq',['consultar_taula_freq',['../class_cjt___idiomes.html#af0cfe6e69c1784af172fe825bdbe61f8',1,'Cjt_Idiomes::consultar_taula_freq()'],['../class_idioma.html#a3d06a9d14291a5b59e0de1a65512ed80',1,'Idioma::consultar_taula_freq()']]]
];
