var searchData=
[
  ['taula_5fde_5ffreq_2ehh',['Taula_de_freq.hh',['../_taula__de__freq_8hh.html',1,'']]]
];
