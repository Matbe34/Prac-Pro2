var searchData=
[
  ['idioma_2ehh',['Idioma.hh',['../_idioma_8hh.html',1,'']]]
];
