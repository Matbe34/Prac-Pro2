var searchData=
[
  ['sumar_5ftaules',['sumar_taules',['../class_taula__de__freq.html#a59add68c3c129a8908907b038d6344f8',1,'Taula_de_freq']]]
];
