var searchData=
[
  ['llegir_5ftaula_5ffreq',['llegir_taula_freq',['../class_taula__de__freq.html#a6e3d7bfaa7227f9b7603864c7a3da2cf',1,'Taula_de_freq']]]
];
