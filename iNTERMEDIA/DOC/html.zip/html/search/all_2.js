var searchData=
[
  ['decodifica',['decodifica',['../class_cjt___idiomes.html#ab77062c4c2b311bbc1fc1143073bc036',1,'Cjt_Idiomes']]]
];
