var searchData=
[
  ['nom_5fidioma',['nom_idioma',['../class_idioma.html#a4f95caa662042f1404ab10319b50ee56',1,'Idioma']]]
];
