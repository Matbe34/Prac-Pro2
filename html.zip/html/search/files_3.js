var searchData=
[
  ['taula_5fde_5ffreq_2ecc',['Taula_de_freq.cc',['../_taula__de__freq_8cc.html',1,'']]],
  ['taula_5fde_5ffreq_2ehh',['Taula_de_freq.hh',['../_taula__de__freq_8hh.html',1,'']]],
  ['treecode_2ecc',['Treecode.cc',['../_treecode_8cc.html',1,'']]],
  ['treecode_2ehh',['Treecode.hh',['../_treecode_8hh.html',1,'']]]
];
