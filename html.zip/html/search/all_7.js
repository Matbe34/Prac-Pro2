var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modifica_5ftaula',['modifica_taula',['../class_taula__de__freq.html#a48ab25af50446a155435d87089e1aab0',1,'Taula_de_freq']]],
  ['modifica_5ftaula_5ffreq',['modifica_taula_freq',['../class_idioma.html#a573da5047cb5acad68a7faf9dc49315f',1,'Idioma']]]
];
