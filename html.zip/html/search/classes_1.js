var searchData=
[
  ['idioma',['Idioma',['../class_idioma.html',1,'']]]
];
