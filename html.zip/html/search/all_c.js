var searchData=
[
  ['taula',['taula',['../class_taula__de__freq.html#a2c7db75db1ccbbe347de775844f3bbd7',1,'Taula_de_freq']]],
  ['taula_5fde_5ffreq',['Taula_de_freq',['../class_taula__de__freq.html',1,'Taula_de_freq'],['../class_taula__de__freq.html#a57b8d780af285f09746da0a96dfd9d61',1,'Taula_de_freq::Taula_de_freq()']]],
  ['taula_5fde_5ffreq_2ecc',['Taula_de_freq.cc',['../_taula__de__freq_8cc.html',1,'']]],
  ['taula_5fde_5ffreq_2ehh',['Taula_de_freq.hh',['../_taula__de__freq_8hh.html',1,'']]],
  ['taulacodis',['taulacodis',['../class_idioma.html#a8eb4228a5182a71efe31c110f2500723',1,'Idioma']]],
  ['taulafreq',['taulafreq',['../class_idioma.html#a51e5f7366342e04f3dae8a4f0fdcca60',1,'Idioma']]],
  ['treecode',['Treecode',['../class_treecode.html',1,'Treecode'],['../class_treecode.html#a190d6af790b7046ed7c96e7a57f0cd38',1,'Treecode::Treecode()'],['../class_treecode.html#a92ec92e0e44e910e546c6d1943bd44ea',1,'Treecode::Treecode(const pair&lt; string, int &gt; &amp;a)'],['../class_treecode.html#a9921e389908e9b5368d1f2cc431e2b13',1,'Treecode::Treecode(const pair&lt; string, int &gt; &amp;a, const Treecode &amp;left, const Treecode &amp;right)'],['../class_idioma.html#ab80d7ef5fec4c922bc65e97e6e3bf968',1,'Idioma::treecode()'],['../class_treecode.html#abd4467b0a13a57fcd3bddf4a60853372',1,'Treecode::treecode()']]],
  ['treecode_2ecc',['Treecode.cc',['../_treecode_8cc.html',1,'']]],
  ['treecode_2ehh',['Treecode.hh',['../_treecode_8hh.html',1,'']]]
];
