var searchData=
[
  ['taula_5fde_5ffreq',['Taula_de_freq',['../class_taula__de__freq.html#a57b8d780af285f09746da0a96dfd9d61',1,'Taula_de_freq']]],
  ['treecode',['Treecode',['../class_treecode.html#a190d6af790b7046ed7c96e7a57f0cd38',1,'Treecode::Treecode()'],['../class_treecode.html#a92ec92e0e44e910e546c6d1943bd44ea',1,'Treecode::Treecode(const pair&lt; string, int &gt; &amp;a)'],['../class_treecode.html#a9921e389908e9b5368d1f2cc431e2b13',1,'Treecode::Treecode(const pair&lt; string, int &gt; &amp;a, const Treecode &amp;left, const Treecode &amp;right)']]]
];
