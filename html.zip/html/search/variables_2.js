var searchData=
[
  ['taula',['taula',['../class_taula__de__freq.html#a2c7db75db1ccbbe347de775844f3bbd7',1,'Taula_de_freq']]],
  ['taulacodis',['taulacodis',['../class_idioma.html#a8eb4228a5182a71efe31c110f2500723',1,'Idioma']]],
  ['taulafreq',['taulafreq',['../class_idioma.html#a51e5f7366342e04f3dae8a4f0fdcca60',1,'Idioma']]],
  ['treecode',['treecode',['../class_idioma.html#ab80d7ef5fec4c922bc65e97e6e3bf968',1,'Idioma::treecode()'],['../class_treecode.html#abd4467b0a13a57fcd3bddf4a60853372',1,'Treecode::treecode()']]]
];
