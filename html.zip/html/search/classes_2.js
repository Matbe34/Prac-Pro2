var searchData=
[
  ['taula_5fde_5ffreq',['Taula_de_freq',['../class_taula__de__freq.html',1,'']]],
  ['treecode',['Treecode',['../class_treecode.html',1,'']]]
];
