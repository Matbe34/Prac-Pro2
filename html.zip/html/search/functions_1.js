var searchData=
[
  ['cerca_5faux',['cerca_aux',['../class_treecode.html#aca0ff4e1e358109783ddc45a32b07425',1,'Treecode']]],
  ['cjt_5fidiomes',['Cjt_Idiomes',['../class_cjt___idiomes.html#af77cbc534e3e83142a818314f5c24ae3',1,'Cjt_Idiomes']]],
  ['codifica',['codifica',['../class_cjt___idiomes.html#ae238d917ce0854e6d93f0ad35aea6aae',1,'Cjt_Idiomes::codifica()'],['../class_idioma.html#af811c85b05ab89e1eb03fc9bcaa3baea',1,'Idioma::codifica()']]],
  ['consultar_5farbre',['consultar_arbre',['../class_treecode.html#a781e52014473e0a905763a6a537cc2aa',1,'Treecode']]],
  ['consultar_5fcodi',['consultar_codi',['../class_treecode.html#adee719707b72a25e70e3c108d0bd60a1',1,'Treecode']]],
  ['consultar_5ftaula_5ffreq',['consultar_taula_freq',['../class_cjt___idiomes.html#af0cfe6e69c1784af172fe825bdbe61f8',1,'Cjt_Idiomes::consultar_taula_freq()'],['../class_idioma.html#a3d06a9d14291a5b59e0de1a65512ed80',1,'Idioma::consultar_taula_freq()'],['../class_taula__de__freq.html#a438f3ce025ca433420891fead5affae4',1,'Taula_de_freq::consultar_taula_freq()']]]
];
