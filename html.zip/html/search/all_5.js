var searchData=
[
  ['idioma',['Idioma',['../class_idioma.html',1,'Idioma'],['../class_idioma.html#acb367feda82c466b5c61378636b901b6',1,'Idioma::Idioma()']]],
  ['idioma_2ecc',['Idioma.cc',['../_idioma_8cc.html',1,'']]],
  ['idioma_2ehh',['Idioma.hh',['../_idioma_8hh.html',1,'']]],
  ['idioma_5festa',['idioma_esta',['../class_cjt___idiomes.html#a4c46be5ecf3b12b3f481ace7d487fdc3',1,'Cjt_Idiomes']]]
];
