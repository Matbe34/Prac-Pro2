var searchData=
[
  ['decodifica',['decodifica',['../class_cjt___idiomes.html#af9f3aa21773963df8ae42ba7fddb8115',1,'Cjt_Idiomes::decodifica()'],['../class_idioma.html#a5e394a011aef7fe91c603b921b4180e2',1,'Idioma::decodifica()'],['../class_treecode.html#a2a7f74ede24cf9e8cfb5c60ccc9b5534',1,'Treecode::decodifica()']]]
];
