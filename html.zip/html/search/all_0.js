var searchData=
[
  ['actualitza_5fidioma',['actualitza_idioma',['../class_cjt___idiomes.html#a6f6bf56a3ab55a2f5f5ddbf6f8b5a3e9',1,'Cjt_Idiomes']]],
  ['actualitza_5ftaulacodis',['actualitza_taulacodis',['../class_idioma.html#ac089a0e4b79ca8f3df040e204a3de7dd',1,'Idioma']]],
  ['actualitzar_5ftreecode',['actualitzar_treecode',['../class_idioma.html#a227386152fe1be34cd3a0a7fce4c4c95',1,'Idioma::actualitzar_treecode()'],['../class_treecode.html#a9b9e9d2f0cce1d4293a7e28ab0ba76f7',1,'Treecode::actualitzar_treecode()']]],
  ['afegir_5fmodificar_5fidioma',['afegir_modificar_idioma',['../class_cjt___idiomes.html#a9e75f643c62886df635403bd3108c1df',1,'Cjt_Idiomes']]]
];
